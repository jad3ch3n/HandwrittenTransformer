import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Eye, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface NoteCreationProps {
  templateId: number;
  onComplete: () => void;
}

export function NoteCreation({ templateId, onComplete }: NoteCreationProps) {
  const { toast } = useToast();
  const [noteText, setNoteText] = useState("");
  const [includeLines, setIncludeLines] = useState(false);
  const [fontSize, setFontSize] = useState("medium");
  const [handwritingData, setHandwritingData] = useState<any>(null);

  const generateHandwritingMutation = useMutation({
    mutationFn: async (data: { text: string; templateId: number; settings: any }) => {
      const response = await apiRequest("POST", "/api/generate-handwriting", data);
      return response.json();
    },
    onSuccess: (data) => {
      setHandwritingData(data.handwritingData);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate handwriting. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleTextChange = (text: string) => {
    setNoteText(text);
    if (text.trim()) {
      generateHandwritingMutation.mutate({
        text,
        templateId,
        settings: { includeLines, fontSize },
      });
    } else {
      setHandwritingData(null);
    }
  };

  const handleExport = () => {
    if (!handwritingData) {
      toast({
        title: "No content",
        description: "Please write some text first.",
        variant: "destructive",
      });
      return;
    }
    onComplete();
  };

  const renderHandwritingPreview = () => {
    if (!handwritingData) {
      return (
        <div className="space-y-3 font-mono text-slate-400 italic text-center py-8">
          <p>Your handwritten text will appear here...</p>
          <p className="text-sm">As you type, we'll convert it to your unique handwriting style</p>
        </div>
      );
    }

    return (
      <svg
        width="100%"
        height="200"
        viewBox={`0 0 ${handwritingData.dimensions.width} ${handwritingData.dimensions.height}`}
        className="border border-slate-200 rounded"
      >
        {includeLines && (
          <>
            <line x1="0" y1="20" x2={handwritingData.dimensions.width} y2="20" stroke="#e2e8f0" strokeWidth="1" />
            <line x1="0" y1="40" x2={handwritingData.dimensions.width} y2="40" stroke="#e2e8f0" strokeWidth="1" />
          </>
        )}
        {handwritingData.paths.map((pathData: any, index: number) => (
          <path
            key={index}
            d={pathData.path}
            stroke="#334155"
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ))}
      </svg>
    );
  };

  return (
    <Card className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-emerald-500 to-teal-600 px-8 py-6">
        <h2 className="text-2xl font-bold text-white mb-2">Create Your Handwritten Note</h2>
        <p className="text-emerald-100">
          Type your message and watch it transform into your personal handwriting style.
        </p>
      </div>

      <CardContent className="p-8">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Text Input Panel */}
          <div className="space-y-4">
            <Label htmlFor="noteText" className="text-sm font-medium text-slate-700">
              Your Message
            </Label>
            <Textarea
              id="noteText"
              value={noteText}
              onChange={(e) => handleTextChange(e.target.value)}
              className="h-64 resize-none"
              placeholder="Start typing your message here..."
            />

            <div className="flex items-center justify-between text-sm text-slate-600">
              <span>Character count: {noteText.length}</span>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeLines"
                    checked={includeLines}
                    onCheckedChange={(checked) => setIncludeLines(checked as boolean)}
                  />
                  <Label htmlFor="includeLines" className="text-sm">
                    Include ruled lines
                  </Label>
                </div>
                <Select value={fontSize} onValueChange={setFontSize}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="large">Large</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Handwriting Preview Panel */}
          <div className="space-y-4">
            <Label className="text-sm font-medium text-slate-700">Handwritten Preview</Label>
            <div className="w-full h-64 bg-white border-2 border-slate-300 rounded-xl p-4 overflow-auto">
              {generateHandwritingMutation.isPending ? (
                <div className="flex items-center justify-center h-full">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : (
                renderHandwritingPreview()
              )}
            </div>

            <div className="flex space-x-2">
              <Button variant="outline" className="flex-1">
                <Eye className="w-4 h-4 mr-2" />
                Full Preview
              </Button>
              <Button onClick={handleExport} className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
