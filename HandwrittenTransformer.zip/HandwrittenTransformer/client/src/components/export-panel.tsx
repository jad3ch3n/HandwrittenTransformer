import { useState } from "react";
import { Download, Share, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

export function ExportPanel() {
  const { toast } = useToast();
  const [format, setFormat] = useState("png");
  const [paperSize, setPaperSize] = useState("a4");
  const [quality, setQuality] = useState("high");
  const [includeMargins, setIncludeMargins] = useState(true);
  const [addWatermark, setAddWatermark] = useState(false);

  const handleDownload = () => {
    // In a real implementation, this would generate and download the file
    toast({
      title: "Download started",
      description: `Your handwritten note is being prepared in ${format.toUpperCase()} format.`,
    });
  };

  const handleShare = () => {
    // In a real implementation, this would open sharing options
    toast({
      title: "Share options",
      description: "Sharing functionality would be implemented here.",
    });
  };

  const handlePrint = () => {
    // In a real implementation, this would open print dialog
    window.print();
  };

  return (
    <Card className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 px-8 py-6">
        <h2 className="text-2xl font-bold text-white mb-2">Export Your Handwritten Note</h2>
        <p className="text-purple-100">
          Save your handwritten note in various formats for printing or sharing.
        </p>
      </div>

      <CardContent className="p-8">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Export Options */}
          <div className="md:col-span-1 space-y-4">
            <h3 className="font-semibold text-slate-900 mb-4">Export Settings</h3>

            <div className="space-y-3">
              <div>
                <Label htmlFor="format" className="text-sm font-medium text-slate-700 mb-2">
                  Format
                </Label>
                <Select value={format} onValueChange={setFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="png">PNG Image</SelectItem>
                    <SelectItem value="pdf">PDF Document</SelectItem>
                    <SelectItem value="jpeg">JPEG Image</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="paperSize" className="text-sm font-medium text-slate-700 mb-2">
                  Paper Size
                </Label>
                <Select value={paperSize} onValueChange={setPaperSize}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="a4">A4</SelectItem>
                    <SelectItem value="letter">Letter</SelectItem>
                    <SelectItem value="a5">A5</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="quality" className="text-sm font-medium text-slate-700 mb-2">
                  Quality
                </Label>
                <Select value={quality} onValueChange={setQuality}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High (300 DPI)</SelectItem>
                    <SelectItem value="medium">Medium (150 DPI)</SelectItem>
                    <SelectItem value="low">Low (72 DPI)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeMargins"
                    checked={includeMargins}
                    onCheckedChange={(checked) => setIncludeMargins(checked as boolean)}
                  />
                  <Label htmlFor="includeMargins" className="text-sm">
                    Include margins
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="addWatermark"
                    checked={addWatermark}
                    onCheckedChange={(checked) => setAddWatermark(checked as boolean)}
                  />
                  <Label htmlFor="addWatermark" className="text-sm">
                    Add watermark
                  </Label>
                </div>
              </div>
            </div>
          </div>

          {/* Preview and Actions */}
          <div className="md:col-span-2 space-y-4">
            <div className="bg-slate-50 rounded-xl p-6 border-2 border-dashed border-slate-300 h-64 flex items-center justify-center">
              <div className="text-center text-slate-500">
                <div className="w-16 h-16 mx-auto mb-4 bg-slate-200 rounded-lg flex items-center justify-center">
                  <Download className="w-8 h-8" />
                </div>
                <p className="text-lg font-medium">Export Preview</p>
                <p className="text-sm">Your handwritten note preview will appear here</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <Button onClick={handleDownload} className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
              <Button onClick={handleShare} className="flex-1 bg-accent hover:bg-emerald-600">
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Button onClick={handlePrint} variant="outline" className="flex-1">
                <Printer className="w-4 h-4 mr-2" />
                Print
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
